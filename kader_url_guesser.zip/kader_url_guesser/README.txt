URL Guesser Tool - by kader11000

How to run:
1. Make sure you have Python 3 and Flask installed.
2. Open terminal in this folder.
3. Run the app with: python app.py
4. Open http://127.0.0.1:5000 in your browser.

Enjoy!