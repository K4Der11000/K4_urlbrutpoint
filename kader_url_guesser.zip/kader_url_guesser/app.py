from flask import Flask, render_template, request, jsonify
import threading
import time

app = Flask(__name__)
guesses = []
proxies = []
results = []
is_paused = False
remaining_time = 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start():
    global guesses, proxies, results, is_paused, remaining_time
    data = request.get_json()
    guesses = data.get("guesses", [])
    proxies = data.get("proxies", [])
    results = []
    is_paused = False
    estimated_time = int(len(guesses) * 0.3 / max(len(proxies) or 1, 1))
    remaining_time = estimated_time
    threading.Thread(target=guess_loop).start()
    return jsonify({"status": "started", "time": estimated_time})

@app.route('/toggle', methods=['POST'])
def toggle():
    global is_paused
    is_paused = not is_paused
    return jsonify({"paused": is_paused})

@app.route('/results')
def get_results():
    return jsonify(results)

def guess_loop():
    global remaining_time
    index = 0
    while index < len(guesses):
        if not is_paused:
            guess = guesses[index]
            proxy = proxies[index % len(proxies)] if proxies else "-"
            results.append({"guess": guess, "proxy": proxy, "status": "Tested"})
            index += 1
        time.sleep(0.3)
        if not is_paused:
            remaining_time -= 0.3

if __name__ == '__main__':
    app.run(debug=True)